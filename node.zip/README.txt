DB is available in DB-export folder
-------------

The URL
1. http://localhost:3000/adduser
2. http://localhost:3000/getuser
3. http://localhost:3000/getuser/:id
4. http://localhost:3000/updateuser/:id
5. http://localhost:3000/deleteuser/:id


Add & update user request

{
  "name": "solomon3",
  "email": "solomon@trawex.com",
  "age": "3"
}